public class HelloWorld {
	public String get(){
    		return "Hello World!";
 	}
	
	public static void main(String[] args){
			HelloWorld hello = new HelloWorld();
        	System.out.println("Hello World!");
    	}
}
