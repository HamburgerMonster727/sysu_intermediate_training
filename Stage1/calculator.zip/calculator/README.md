# README

文件结构：

- HelloWorld
  - 任务2
    - 熟悉JDK的环境并学习JAVA语言，完成HelloWorld的编译运行
  - 任务3
    - 熟悉Ant的环境并学习Ant，利用Ant实现HelloWorld的自动编译
  - 任务5
    - 学习Junit，利用Ant、Junit测试通过HelloWorldTest
- Calculator
  - 任务4
    - 学习Java语言，并编写Java小程序，实现计数器
  - 任务6
    - 学习并配置SonarQube，利用SonarQube测试任务4制作的计数器



