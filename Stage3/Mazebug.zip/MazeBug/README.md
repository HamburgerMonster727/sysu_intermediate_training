gridworld.jar为打包好的新jar

ant默认执行run，打开gui

从map文件夹加载地图，进行测试

