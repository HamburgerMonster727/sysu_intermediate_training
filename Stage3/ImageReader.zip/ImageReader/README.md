ant默认执行run，打开gui

ant junit执行测试